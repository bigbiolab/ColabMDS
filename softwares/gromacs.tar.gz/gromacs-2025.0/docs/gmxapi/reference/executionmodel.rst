===============
Execution model
===============

stub


