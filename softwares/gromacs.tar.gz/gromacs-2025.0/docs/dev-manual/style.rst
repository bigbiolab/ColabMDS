.. _style-guidelines:

Style guidelines
================

Different style guidelines are available under the respective sections of
this page.

.. toctree::
   :maxdepth: 2

   formatting
   includestyle
   naming
   language-features
   reportstyle
   commitstyle
   error-handling

.. todo:: Add more guidelines
